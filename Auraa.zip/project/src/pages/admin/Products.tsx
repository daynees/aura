import React from 'react';
import AdminLayout from '../../components/admin/Layout';
import ProductList from '../../components/admin/products/ProductList';
import AddProductButton from '../../components/admin/products/AddProductButton';

export default function AdminProducts() {
  return (
    <AdminLayout>
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <h1 className="text-2xl font-bold">Products</h1>
          <AddProductButton />
        </div>
        <ProductList />
      </div>
    </AdminLayout>
  );
}