import React from 'react';
import AdminLayout from '../../components/admin/Layout';
import OrderList from '../../components/admin/orders/OrderList';
import OrderFilters from '../../components/admin/orders/OrderFilters';

export default function AdminOrders() {
  return (
    <AdminLayout>
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <h1 className="text-2xl font-bold">Orders</h1>
        </div>
        <OrderFilters />
        <OrderList />
      </div>
    </AdminLayout>
  );
}