import React from 'react';
import { useNavigate } from 'react-router-dom';
import AdminLayout from '../../components/admin/Layout';
import DashboardStats from '../../components/admin/DashboardStats';
import RecentOrders from '../../components/admin/RecentOrders';

export default function AdminDashboard() {
  return (
    <AdminLayout>
      <div className="space-y-6">
        <h1 className="text-2xl font-bold">Dashboard</h1>
        <DashboardStats />
        <RecentOrders />
      </div>
    </AdminLayout>
  );
}