export interface ProductVariant {
  id: string;
  size: string;
  color: string;
  stock: number;
  price: number;
}

export interface Product {
  id: string;
  name: string;
  description: string;
  base_price: number;
  variants: ProductVariant[];
  images: {
    id: string;
    url: string;
    order: number;
  }[];
}