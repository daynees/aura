import React from 'react';
import { Link } from 'react-router-dom';
import type { Product } from '../types/product';

interface ProductCardProps {
  product: Product;
}

export default function ProductCard({ product }: ProductCardProps) {
  const mainImage = product.images.sort((a, b) => a.order - b.order)[0]?.url;
  const minPrice = Math.min(...product.variants.map(v => v.price));

  return (
    <Link to={`/product/${product.id}`} className="group">
      <div className="aspect-square overflow-hidden bg-gray-100">
        <img
          src={mainImage}
          alt={product.name}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
        />
      </div>
      <div className="mt-4">
        <h3 className="text-lg font-medium text-gray-900">{product.name}</h3>
        <p className="mt-1 text-sm text-gray-500">From ${minPrice.toFixed(2)}</p>
      </div>
    </Link>
  );
}