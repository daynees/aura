import React from 'react';
import { Link } from 'react-router-dom';
import { ShoppingBag, User } from 'lucide-react';
import { useCart } from '../stores/cartStore';

export default function Navbar() {
  const { items } = useCart();
  
  return (
    <nav className="bg-black text-white py-4">
      <div className="container mx-auto px-4 flex items-center justify-between">
        <Link to="/" className="text-2xl font-bold">AURA</Link>
        
        <div className="flex items-center space-x-8">
          <Link to="/shop" className="hover:text-gray-300">Shop</Link>
          <Link to="/cart" className="relative">
            <ShoppingBag className="w-6 h-6" />
            {items.length > 0 && (
              <span className="absolute -top-2 -right-2 bg-white text-black text-xs rounded-full w-5 h-5 flex items-center justify-center">
                {items.length}
              </span>
            )}
          </Link>
          <Link to="/admin/login">
            <User className="w-6 h-6" />
          </Link>
        </div>
      </div>
    </nav>
  );
}