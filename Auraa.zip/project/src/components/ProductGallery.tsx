import React, { useState } from 'react';

interface ProductGalleryProps {
  images: Array<{ id: string; url: string; order: number }>;
}

export default function ProductGallery({ images }: ProductGalleryProps) {
  const [selectedImage, setSelectedImage] = useState(images[0]?.url);
  const sortedImages = [...images].sort((a, b) => a.order - b.order);

  return (
    <div className="grid gap-4">
      <div className="aspect-square w-full overflow-hidden bg-gray-100">
        <img
          src={selectedImage}
          alt="Product"
          className="w-full h-full object-cover"
        />
      </div>
      <div className="grid grid-cols-4 gap-4">
        {sortedImages.map((image) => (
          <button
            key={image.id}
            onClick={() => setSelectedImage(image.url)}
            className={`aspect-square overflow-hidden bg-gray-100 ${
              selectedImage === image.url ? 'ring-2 ring-black' : ''
            }`}
          >
            <img
              src={image.url}
              alt="Product thumbnail"
              className="w-full h-full object-cover"
            />
          </button>
        ))}
      </div>
    </div>
  );
}