import React from 'react';
import { Eye, CheckCircle } from 'lucide-react';
import { supabase } from '../../../lib/supabase';

interface Order {
  id: string;
  customer_name: string;
  customer_email: string;
  total_amount: number;
  status: string;
  created_at: string;
}

interface OrderListItemProps {
  order: Order;
  onUpdate: () => void;
}

export default function OrderListItem({ order, onUpdate }: OrderListItemProps) {
  const handleUpdateStatus = async (newStatus: string) => {
    try {
      const { error } = await supabase
        .from('orders')
        .update({ status: newStatus })
        .eq('id', order.id);

      if (error) throw error;
      onUpdate();
    } catch (err) {
      console.error('Error updating order status:', err);
      alert('Failed to update order status');
    }
  };

  return (
    <tr>
      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
        {order.id.slice(0, 8)}
      </td>
      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
        <div>
          <div className="font-medium">{order.customer_name}</div>
          <div className="text-gray-400">{order.customer_email}</div>
        </div>
      </td>
      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
        ${order.total_amount.toFixed(2)}
      </td>
      <td className="px-6 py-4 whitespace-nowrap">
        <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
          order.status === 'completed' ? 'bg-green-100 text-green-800' :
          order.status === 'pending' ? 'bg-yellow-100 text-yellow-800' :
          'bg-gray-100 text-gray-800'
        }`}>
          {order.status}
        </span>
      </td>
      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
        {new Date(order.created_at).toLocaleDateString()}
      </td>
      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
        <div className="flex space-x-2">
          <button className="text-blue-600 hover:text-blue-800">
            <Eye className="w-5 h-5" />
          </button>
          {order.status !== 'completed' && (
            <button
              onClick={() => handleUpdateStatus('completed')}
              className="text-green-600 hover:text-green-800"
            >
              <CheckCircle className="w-5 h-5" />
            </button>
          )}
        </div>
      </td>
    </tr>
  );
}