import React from 'react';

export default function OrderFilters() {
  return (
    <div className="flex gap-4">
      <select className="rounded-md border-gray-300 shadow-sm focus:border-black focus:ring-black">
        <option value="all">All Status</option>
        <option value="pending">Pending</option>
        <option value="processing">Processing</option>
        <option value="completed">Completed</option>
      </select>

      <input
        type="date"
        className="rounded-md border-gray-300 shadow-sm focus:border-black focus:ring-black"
      />
    </div>
  );
}