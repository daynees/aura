import React from 'react';
import { Pencil, Trash2 } from 'lucide-react';
import type { Product } from '../../../types/product';
import { supabase } from '../../../lib/supabase';

interface ProductListItemProps {
  product: Product;
  onUpdate: () => void;
}

export default function ProductListItem({ product, onUpdate }: ProductListItemProps) {
  const totalStock = product.variants.reduce((sum, variant) => sum + variant.stock, 0);
  const mainImage = product.images.sort((a, b) => a.order - b.order)[0]?.url;

  const handleDelete = async () => {
    if (!confirm('Are you sure you want to delete this product?')) return;

    try {
      const { error } = await supabase
        .from('products')
        .delete()
        .eq('id', product.id);

      if (error) throw error;
      onUpdate();
    } catch (err) {
      console.error('Error deleting product:', err);
      alert('Failed to delete product');
    }
  };

  return (
    <tr>
      <td className="px-6 py-4 whitespace-nowrap">
        <div className="flex items-center">
          <div className="h-16 w-16 flex-shrink-0">
            <img
              src={mainImage}
              alt={product.name}
              className="h-16 w-16 object-cover rounded"
            />
          </div>
          <div className="ml-4">
            <div className="text-sm font-medium text-gray-900">{product.name}</div>
            <div className="text-sm text-gray-500">{product.description}</div>
          </div>
        </div>
      </td>
      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
        ${product.base_price.toFixed(2)}
      </td>
      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
        {product.variants.length}
      </td>
      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
        {totalStock}
      </td>
      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
        <div className="flex space-x-2">
          <button className="text-blue-600 hover:text-blue-800">
            <Pencil className="w-5 h-5" />
          </button>
          <button
            onClick={handleDelete}
            className="text-red-600 hover:text-red-800"
          >
            <Trash2 className="w-5 h-5" />
          </button>
        </div>
      </td>
    </tr>
  );
}