import React, { useState } from 'react';
import { Plus } from 'lucide-react';
import AddProductModal from './AddProductModal';

export default function AddProductButton() {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <>
      <button
        onClick={() => setIsOpen(true)}
        className="bg-black text-white px-4 py-2 rounded-md hover:bg-gray-900 flex items-center"
      >
        <Plus className="w-5 h-5 mr-2" />
        Add Product
      </button>
      {isOpen && <AddProductModal onClose={() => setIsOpen(false)} />}
    </>
  );
}