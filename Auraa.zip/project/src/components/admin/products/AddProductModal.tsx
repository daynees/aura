import React from 'react';

export default function AddProductModal({ onClose }: { onClose: () => void }) {
    return (
        <div className="modal">
            <div className="modal-content">
                <h2>Add Product</h2>
                <button onClick={onClose}>Close</button>
                <form>
                    <div>
                        <label>Product Name</label>
                        <input type="text" />
                    </div>
                    <div>
                        <label>Price</label>
                        <input type="number" />
                    </div>
                    <button type="submit">Save</button>
                </form>
            </div>
        </div>
    );
}
