import React, { useEffect, useState } from 'react';
import { supabase } from '../../lib/supabase';

export default function DashboardStats() {
  const [stats, setStats] = useState({
    totalOrders: 0,
    totalRevenue: 0,
    totalProducts: 0,
  });

  useEffect(() => {
    async function fetchStats() {
      const [ordersData, productsData] = await Promise.all([
        supabase
          .from('orders')
          .select('total_amount')
          .eq('status', 'completed'),
        supabase
          .from('products')
          .select('id'),
      ]);

      const totalOrders = ordersData.data?.length || 0;
      const totalRevenue = ordersData.data?.reduce((sum, order) => sum + order.total_amount, 0) || 0;
      const totalProducts = productsData.data?.length || 0;

      setStats({ totalOrders, totalRevenue, totalProducts });
    }

    fetchStats();
  }, []);

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      <div className="bg-white p-6 rounded-lg shadow-sm">
        <h3 className="text-sm font-medium text-gray-500">Total Orders</h3>
        <p className="mt-2 text-3xl font-bold">{stats.totalOrders}</p>
      </div>
      <div className="bg-white p-6 rounded-lg shadow-sm">
        <h3 className="text-sm font-medium text-gray-500">Total Revenue</h3>
        <p className="mt-2 text-3xl font-bold">${stats.totalRevenue.toFixed(2)}</p>
      </div>
      <div className="bg-white p-6 rounded-lg shadow-sm">
        <h3 className="text-sm font-medium text-gray-500">Total Products</h3>
        <p className="mt-2 text-3xl font-bold">{stats.totalProducts}</p>
      </div>
    </div>
  );
}