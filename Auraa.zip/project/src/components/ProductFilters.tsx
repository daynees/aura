import React from 'react';

interface ProductFiltersProps {
  onCategoryChange: (category: string) => void;
  onPriceRangeChange: (range: [number, number]) => void;
  selectedCategory: string;
}

export default function ProductFilters({
  onCategoryChange,
  onPriceRangeChange,
  selectedCategory,
}: ProductFiltersProps) {
  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-medium text-gray-900">Categories</h3>
        <div className="mt-4 space-y-2">
          {['all', 'hoodies', 'polos'].map((category) => (
            <button
              key={category}
              onClick={() => onCategoryChange(category)}
              className={`block w-full text-left px-2 py-1 rounded ${
                selectedCategory === category
                  ? 'bg-black text-white'
                  : 'text-gray-600 hover:bg-gray-100'
              }`}
            >
              {category.charAt(0).toUpperCase() + category.slice(1)}
            </button>
          ))}
        </div>
      </div>

      <div>
        <h3 className="text-lg font-medium text-gray-900">Price Range</h3>
        <div className="mt-4 space-y-4">
          {[
            [0, 50],
            [50, 100],
            [100, 200],
            [200, Infinity],
          ].map(([min, max]) => (
            <button
              key={`${min}-${max}`}
              onClick={() => onPriceRangeChange([min, max])}
              className="block w-full text-left px-2 py-1 text-gray-600 hover:bg-gray-100 rounded"
            >
              {max === Infinity
                ? `$${min}+`
                : `$${min} - $${max}`}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}