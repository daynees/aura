import React from 'react';
import type { ProductVariant } from '../types/product';

interface ProductVariantSelectorProps {
  variants: ProductVariant[];
  selectedSize: string;
  selectedColor: string;
  onSizeChange: (size: string) => void;
  onColorChange: (color: string) => void;
}

export default function ProductVariantSelector({
  variants,
  selectedSize,
  selectedColor,
  onSizeChange,
  onColorChange,
}: ProductVariantSelectorProps) {
  const uniqueSizes = Array.from(new Set(variants.map(v => v.size)));
  const uniqueColors = Array.from(new Set(variants.map(v => v.color)));

  return (
    <div className="space-y-6">
      <div>
        <label className="text-sm font-medium text-gray-700">Size</label>
        <div className="grid grid-cols-4 gap-2 mt-2">
          {uniqueSizes.map((size) => (
            <button
              key={size}
              onClick={() => onSizeChange(size)}
              className={`py-2 px-4 text-sm border rounded-md ${
                selectedSize === size
                  ? 'border-black bg-black text-white'
                  : 'border-gray-300 hover:border-gray-400'
              }`}
            >
              {size}
            </button>
          ))}
        </div>
      </div>

      <div>
        <label className="text-sm font-medium text-gray-700">Color</label>
        <div className="grid grid-cols-4 gap-2 mt-2">
          {uniqueColors.map((color) => (
            <button
              key={color}
              onClick={() => onColorChange(color)}
              className={`py-2 px-4 text-sm border rounded-md ${
                selectedColor === color
                  ? 'border-black bg-black text-white'
                  : 'border-gray-300 hover:border-gray-400'
              }`}
            >
              {color}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}