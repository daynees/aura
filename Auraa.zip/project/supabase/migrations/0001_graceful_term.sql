/*
  # Initial Schema Setup for Aura Clothing Store

  1. New Tables
    - users (admin users)
      - id (uuid, primary key)
      - email (text, unique)
      - created_at (timestamp)
      - is_admin (boolean)
    
    - products
      - id (uuid, primary key)
      - name (text)
      - description (text)
      - base_price (numeric)
      - created_at (timestamp)
      - updated_at (timestamp)
    
    - product_variants
      - id (uuid, primary key)
      - product_id (uuid, foreign key)
      - size (text)
      - color (text)
      - stock (integer)
      - price (numeric)
    
    - product_images
      - id (uuid, primary key)
      - product_id (uuid, foreign key)
      - url (text)
      - order (integer)
    
    - orders
      - id (uuid, primary key)
      - customer_name (text)
      - customer_email (text)
      - customer_phone (text)
      - shipping_address (text)
      - payment_method (text)
      - status (text)
      - total_amount (numeric)
      - created_at (timestamp)
    
    - order_items
      - id (uuid, primary key)
      - order_id (uuid, foreign key)
      - product_variant_id (uuid, foreign key)
      - quantity (integer)
      - price (numeric)

  2. Security
    - Enable RLS on all tables
    - Add policies for admin access
*/

-- Users table
CREATE TABLE users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text UNIQUE NOT NULL,
  created_at timestamptz DEFAULT now(),
  is_admin boolean DEFAULT false
);

ALTER TABLE users ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read own data"
  ON users
  FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

-- Products table
CREATE TABLE products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text,
  base_price numeric NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE products ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read products"
  ON products
  FOR SELECT
  TO authenticated, anon
  USING (true);

CREATE POLICY "Only admins can modify products"
  ON products
  USING (
    auth.uid() IN (
      SELECT id FROM users WHERE is_admin = true
    )
  );

-- Product variants table
CREATE TABLE product_variants (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id uuid REFERENCES products(id) ON DELETE CASCADE,
  size text NOT NULL,
  color text NOT NULL,
  stock integer NOT NULL DEFAULT 0,
  price numeric NOT NULL,
  UNIQUE(product_id, size, color)
);

ALTER TABLE product_variants ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read variants"
  ON product_variants
  FOR SELECT
  TO authenticated, anon
  USING (true);

CREATE POLICY "Only admins can modify variants"
  ON product_variants
  USING (
    auth.uid() IN (
      SELECT id FROM users WHERE is_admin = true
    )
  );

-- Product images table
CREATE TABLE product_images (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id uuid REFERENCES products(id) ON DELETE CASCADE,
  url text NOT NULL,
  "order" integer NOT NULL DEFAULT 0
);

ALTER TABLE product_images ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read images"
  ON product_images
  FOR SELECT
  TO authenticated, anon
  USING (true);

CREATE POLICY "Only admins can modify images"
  ON product_images
  USING (
    auth.uid() IN (
      SELECT id FROM users WHERE is_admin = true
    )
  );

-- Orders table
CREATE TABLE orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_name text NOT NULL,
  customer_email text NOT NULL,
  customer_phone text NOT NULL,
  shipping_address text NOT NULL,
  payment_method text NOT NULL,
  status text NOT NULL DEFAULT 'pending',
  total_amount numeric NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE orders ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can create orders"
  ON orders
  FOR INSERT
  TO authenticated, anon
  WITH CHECK (true);

CREATE POLICY "Only admins can read all orders"
  ON orders
  FOR SELECT
  USING (
    auth.uid() IN (
      SELECT id FROM users WHERE is_admin = true
    )
  );

-- Order items table
CREATE TABLE order_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid REFERENCES orders(id) ON DELETE CASCADE,
  product_variant_id uuid REFERENCES product_variants(id),
  quantity integer NOT NULL,
  price numeric NOT NULL
);

ALTER TABLE order_items ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can create order items"
  ON order_items
  FOR INSERT
  TO authenticated, anon
  WITH CHECK (true);

CREATE POLICY "Only admins can read all order items"
  ON order_items
  FOR SELECT
  USING (
    auth.uid() IN (
      SELECT id FROM users WHERE is_admin = true
    )
  );